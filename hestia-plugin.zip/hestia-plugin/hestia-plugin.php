<?php

/*
 * Admin Page Framework v3.9.1 by Michael Uno
 * Compiled with Admin Page Framework Compiler <https://github.com/michaeluno/admin-page-framework-compiler>
 * <https://en.michaeluno.jp/admin-page-framework>
 * Copyright (c) 2013-2022, Michael Uno; Licensed under MIT <https://opensource.org/licenses/MIT>
 * Compiled on 2022-07-07
 * Included Components: Admin Pages
 */
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://hostwest.net
 * @since             2.0.0
 * @package           Hestia
 *
 * @wordpress-plugin
 * Plugin Name:       Hestia Plugin
 * Plugin URI:        https://hostwest.net/
 * Description:       An Alpha PlugIn for WordPress to provide API access and control to HestiaCP. Uses the amazing APF framework.
 * Version:           2.0.0
 * Author:            Edward C
 * Author URI:        https://hostwest.net/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       hestia-plugin
 * Domain Path:       /languages
 */

// Set your own path here
include( dirname( __FILE__ ) . '/library/admin-page-framework/admin-page-framework.php' );
if ( ! class_exists( 'MyFirstPlugin_AdminPageFramework' ) ) {
    return;
}

class MyFirstPlugin extends MyFirstPlugin_AdminPageFramework {

    public function setUp() {

        $this->setRootMenuPage( 'Hestia' ); 

        $this->addSubMenuItem(
            array(
                'title'     => 'Hestia Plugin',
                'page_slug' => 'Hestia Plugin'
            )
        );
        $this->addSubMenuItem(
            array(
                'title'     => 'API Key',
                'page_slug' => 'API Key'
            )
        );
        $this->addSubMenuItem(
            array(
                'title'     => 'Server Config',
                'page_slug' => 'Server Config'
            )
        );
        $this->addSubMenuItem(
            array(
                'title'     => 'Create User',
                'page_slug' => 'Create User'
            )
        );
    }
    /**
     * Triggered in the middle of rendering the page.
     * 
     * Inserts your custom contents here.
     * 
     * @remark      do_{page slug}
     */
    public function do_hestia_plugin() {

        ?>
        <h3>Welcome to the experimental Open Source HestiaCP API Admin for WordPress</h3>
        <p>Always set your HestiaCP API Key before trying a Command.</p>
        <p>This Plugin is built using the amazing APF (Admin Plugin Framework).</p>
        <?php   

    }

    public function OLD_do_api_key() {

        ?>
        <h3>Set the HestiaCP API Key</h3>
        <p>This is where we set the HestiaCP API Key</p>
        <?php   

    }

    public function OLD_do_create_user() {
    
        ?>
        <h3>The Create User call - non API</h3>
        <p>This allows us to Create a valid User in HestiaCP without using an API Key</p>
        <?php   

    }

    public function load_server_config( $oAdminPage ) {
    
     // Server credentials
        //$hst_hostname = 'cp.hostwest.net';
        //$hst_port = '2083';
        //$hst_username = 'admin';
        //$hst_password = 'Dinnerbox2022!';
        //$hst_returncode = 'yes';
        //$hst_command = 'v-add-user';


        $this->addSettingFields(
            array(    // Single text field
                'field_id'      => 'hst_hostname',
                'type'          => 'text',
                'title'         => 'Hostname',
                'description'   => 'Server Hostname',   
            ),
            array(    // Single text field
                'field_id'      => 'hst_port',
                'type'          => 'text',
                'title'         => 'Host Port',
                'description'   => 'Server Host Port',   
            ),
            array(    // Single text field
                'field_id'      => 'hst_username',
                'type'          => 'text',
                'title'         => 'CP Admin Username',
                'description'   => 'Admin Username',   
            ),
            array(    // Single text field
                'field_id'      => 'hst_password',
                'type'          => 'password',
                'title'         => 'CP Admin Password',
                'description'   => 'Admin Password',   
            ),
            array( // Submit button
                'field_id'      => 'submit_button',
                'type'          => 'submit',
            )  
        );         
        
    }

    public function load_api_key( $oAdminPage ) {
        
        $this->addSettingFields(
            array(    // Single text field
                'field_id'      => 'api_key',
                'type'          => 'text',
                'title'         => 'API Key',
                'description'   => 'HestiaCP Admin API Key',   
            ),
            array( // Submit button
                'field_id'      => 'submit_button',
                'type'          => 'submit',
            )  
        );         
        
    }

    /**
     * One of the pre-defined methods which is triggered when the registered page loads.
     * 
     * Here we add form fields.
     * @callback        action      load_{page slug}
     */
    public function load_create_user( $oAdminPage ) {
        
        $this->addSettingFields(
            array(    // Single text field
                'field_id'      => 'user_name',
                'type'          => 'text',
                'title'         => 'User Name',
                'description'   => 'Type User Name.',   
            ),
            array(    // Single text field
                'field_id'      => 'password',
                'type'          => 'password',
                'title'         => 'Password',
                'description'   => 'Type Password.',   
            ),
            array(    // Single text field
                'field_id'      => 'email',
                'type'          => 'text',
                'title'         => 'Email Address',
                'description'   => 'Type Email Address.',
            ),
            array(    // Single text field
                'field_id'      => 'package',
                'type'          => 'text',
                'title'         => 'Packages',
                'description'   => 'HestiaCP Package (use default)',
            ),   
            array(    // Single text field
                'field_id'      => 'first_name',
                'type'          => 'text',
                'title'         => 'First Name',
                'description'   => 'First Name',
            ), 
            array(    // Single text field
                'field_id'      => 'last_name',
                'type'          => 'text',
                'title'         => 'Last Name',
                'description'   => 'Last Name',
            ),    
            array( // Submit button
                'field_id'      => 'submit_button',
                'type'          => 'submit',
            )   
        );         
        
    }
    
    /**
     * One of the pre-defined methods which is triggered when the page contents is going to be rendered.
     * @callback        action      do_{page slug}
     */
    public function do_create_user() {
                    
        // Server credentials
        $hst_hostname = 'cp.hostwest.net';
        $hst_port = '2083';
        $hst_username = 'admin';
        $hst_password = 'Dinnerbox2022!';
        $hst_returncode = 'yes';
        $hst_command = 'v-add-user';

        // New Account
            // $username = 'user_name';
            $username = $user_name;

            $password = 'password';
            $email = 'demo@gmail.com';
            $package = 'default';
            $first_name = 'Rust';
            $last_name = 'Cohle';

        // Prepare POST query
        $postvars = array(
            'user' => $hst_username,
            'password' => $hst_password,
            'returncode' => $hst_returncode,
            'cmd' => $hst_command,
            'arg1' => $username,
            'arg2' => $password,
            'arg3' => $email,
            'arg4' => $package,
            'arg5' => $first_name,
            'arg6' => $last_name
        );

        // Send POST query via cURL
        $postdata = http_build_query($postvars);
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, 'https://' . $hst_hostname . ':' . $hst_port . '/api/');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER,true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postdata);
        $answer = curl_exec($curl);

        // Check result
        if($answer === 0) {
            echo "User account has been successfuly created\n";
        } else {
            echo "Query returned error code: " .$answer. "\n";
        }

        // Show the saved option value.
        // The extended class name is used as the option key. This can be changed by passing a custom string to the constructor.
        echo '<h3>Saved Fields</h3>';
        echo '<pre>my_text_field: ' . MyFirstPlugin::getOption( 'MyFirstPlugin', 'user_name', 'default text value' ) . '</pre>';
        echo '<pre>my_password_field: ' . MyFirstPlugin::getOption( 'MyFirstPlugin', 'password', 'default text value' ) . '</pre>';
        echo '<pre>my_text_field: ' . MyFirstPlugin::getOption( 'MyFirstPlugin', 'email', 'default text value' ) . '</pre>';
        echo '<pre>my_text_field: ' . MyFirstPlugin::getOption( 'MyFirstPlugin', 'package', 'default text value' ) . '</pre>';


        echo '<h3>Show all the options as an array</h3>';
      
        echo $this->oDebug->get( MyFirstPlugin::getOption( 'MyFirstPlugin' ) );
       
    }



}

new MyFirstPlugin;